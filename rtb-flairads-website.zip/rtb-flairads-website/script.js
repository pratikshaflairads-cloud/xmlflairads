const domain = "rtbflairads.com";
const copyButtons = [
  ["copyDomain", "copyStatus", "Domain copied to clipboard."],
  ["copyContact", "contactStatus", "Domain name copied."]
];
copyButtons.forEach(([buttonId, statusId, message]) => {
  const button = document.getElementById(buttonId);
  const status = document.getElementById(statusId);
  button.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(domain);
      status.textContent = message;
    } catch {
      status.textContent = "Domain: " + domain;
    }
  });
});
document.getElementById("year").textContent = new Date().getFullYear();
