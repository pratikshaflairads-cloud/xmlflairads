# RTB FlairAds parked-domain landing page

A responsive static landing page for `rtbflairads.com`.

## Preview locally
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Create a GitHub repository (for example, `rtbflairads-site`).
2. Upload `index.html`, `style.css`, `script.js`, and `CNAME` to the repository root.
3. Open **Settings → Pages** and choose the branch/folder you want to publish.
4. Under **Custom domain**, enter `rtbflairads.com` and save.
5. At your domain registrar, configure the DNS records recommended by GitHub Pages for an apex domain. Add a `www` CNAME if you also want `www.rtbflairads.com`.
6. After DNS resolves, enable **Enforce HTTPS** in the Pages settings.

Read the official instructions: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

Important:
- You must own or register `rtbflairads.com`; this package cannot purchase a domain or publish to your account.
- Keep the `CNAME` file containing only the domain name.
- DNS updates can take time to propagate.
- This is a parked-domain landing page. It does not include an advertising network, domain sale checkout, or a working contact email. Add your actual contact details before publishing if you want visitors to contact you.
